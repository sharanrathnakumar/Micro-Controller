/* 
 * File:   main.h
 * Author: sharan
 *
 * Created on 8 March, 2023, 6:29 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "init_config.h"
#define LED_ARRAY PORTD
#define LED_ARRAY_DDR TRISD
#define OFF 0x00
#define DELAY 1000000

#endif	/* MAIN_H */

