/* 
 * File:   init_config.h
 * Author: sharan
 *
 * Created on 8 March, 2023, 6:29 PM
 */

#ifndef INIT_CONFIG_H
#define INIT_CONFIG_H
void init_config(void);
#endif

